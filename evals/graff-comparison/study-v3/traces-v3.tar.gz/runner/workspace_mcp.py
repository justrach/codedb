import json, os, subprocess, sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
editable = json.loads(sys.argv[2])
test = sys.argv[3]
allowed = set(subprocess.check_output(['/usr/bin/git', '-C', str(root), 'ls-files'], text=True).splitlines())
def schema(name, description, properties, required):
    return dict(name=name, description=description, inputSchema=dict(type='object', properties=properties, required=required))
catalog = [
    schema('list_files', 'List the fixture files available for reading. No access outside this task.', {}, []),
    schema('search_files', 'Search literal text in fixture files. Returns up to 80 numbered matching lines.', {'query':{'type':'string'}}, ['query']),
    schema('read_file', 'Read a fixture file, with line numbers. Paths are relative to the fixture root.', {'path': {'type':'string'}}, ['path']),
    schema('write_file', 'Replace the implementation file with complete new content. Tests and specification are immutable.', {'path':{'type':'string'}, 'content':{'type':'string'}}, ['path','content']),
    schema('run_tests', 'Run the existing visible fixture tests against your current implementation.', {}, []),
]
for line in sys.stdin:
    try:
        m = json.loads(line)
        if 'id' not in m: continue
        method = m.get('method')
        if method == 'initialize':
            result = dict(protocolVersion=m.get('params',{}).get('protocolVersion','2024-11-05'), capabilities={'tools':{}}, serverInfo={'name':'fixture-workspace','version':'1'})
        elif method == 'tools/list': result = {'tools':catalog}
        elif method == 'ping': result = {}
        elif method == 'tools/call':
            try:
                name=m['params']['name']; args=m['params'].get('arguments',{})
                if name == 'list_files':text='\n'.join(sorted(allowed))
                elif name == 'search_files':
                    query=args['query'];assert query and len(query)<=200,'Use a nonempty query of at most 200 characters'
                    hits=[]
                    for rel in sorted(allowed):
                        for i,line in enumerate((root/rel).read_text().splitlines(),1):
                            if query.casefold() in line.casefold():hits.append(f'{rel}:{i}: {line[:300]}')
                    text='\n'.join(hits[:80])+ ('\n[more matches omitted]' if len(hits)>80 else '')
                elif name == 'run_tests':
                    p=subprocess.run([sys.executable, test], cwd=root, capture_output=True, text=True, timeout=30, env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'})
                    text=json.dumps({'exit_code':p.returncode,'stdout':p.stdout[-16000:],'stderr':p.stderr[-16000:]})
                else:
                    rel=args['path']; path=(root/rel).resolve()
                    assert rel in allowed and path.is_relative_to(root), 'Path outside fixture'
                    if name == 'read_file': text='\n'.join(f'{i}: {s}' for i,s in enumerate(path.read_text().splitlines(),1))
                    elif name == 'write_file':
                        assert rel in editable, 'Only implementation files may be edited'
                        path.write_text(args['content']); text='Saved '+rel
                    else: raise ValueError('Unknown tool')
                result={'content':[{'type':'text','text':text}]}
            except Exception as e: result={'isError':True,'content':[{'type':'text','text':str(e)}]}
        else:
            print(json.dumps({'jsonrpc':'2.0','id':m['id'],'error':{'code':-32601,'message':'Unsupported method'}}),flush=True); continue
        print(json.dumps({'jsonrpc':'2.0','id':m['id'],'result':result}),flush=True)
    except Exception: pass
