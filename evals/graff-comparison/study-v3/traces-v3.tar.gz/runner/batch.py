import concurrent.futures,hashlib,json,subprocess,sys,time
from pathlib import Path
import run
B=Path(__file__).parent;m=json.loads((B/'manifest.json').read_text())
assert len(json.loads((B/'validation.json').read_text()))==8
freeze={str(p.name):hashlib.sha256(p.read_bytes()).hexdigest() for p in [B/'manifest.json',B/'run.py',B/'workspace_mcp.py',B/'proxy.py']}
freeze.update(graff=run.sha(Path(run.GRAFF)),codedb=run.sha(Path(run.BIN)),started=time.time())
(B/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
def one(ident,arm):
    p=subprocess.run([sys.executable,str(B/'run.py'),ident,arm],cwd=B,capture_output=True,text=True)
    print(p.stdout,flush=True)
    if p.returncode:print(p.stderr,flush=True)
    return arm,p.returncode
for index,block in enumerate(m['blocks'],1):
    print(f'BLOCK {index}/{len(m["blocks"])} {block["id"]}',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(one,block['id'],arm) for arm in block['launch_order']]
        results=[f.result() for f in concurrent.futures.as_completed(futures)]
    if any(code for arm,code in results):raise SystemExit('Collector error; inspect saved outputs before continuing')
assert run.sha(Path(run.GRAFF))==freeze['graff'];assert run.sha(Path(run.BIN))==freeze['codedb']
print('COMPLETE: 48 attempts; binary hashes unchanged',flush=True)
