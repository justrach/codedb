import json,subprocess,sys,threading,time
log=open(sys.argv[1],'a',buffering=1);lock=threading.Lock()
p=subprocess.Popen(sys.argv[2:],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def copy(src,dst,direction):
    for line in src:
        try: value=json.loads(line)
        except Exception: value=line.decode(errors='replace')
        with lock: log.write(json.dumps({'time_ns':time.time_ns(),'direction':direction,'message':value})+'\n')
        try: dst.write(line);dst.flush()
        except (BrokenPipeError,ValueError): break
    if direction=='in':
        try:p.stdin.close()
        except Exception:pass
threads=[threading.Thread(target=copy,args=(sys.stdin.buffer,p.stdin,'in'),daemon=True),threading.Thread(target=copy,args=(p.stdout,sys.stdout.buffer,'out'),daemon=True),threading.Thread(target=copy,args=(p.stderr,sys.stderr.buffer,'stderr'),daemon=True)]
for t in threads:t.start()
code=p.wait()
for t in threads[1:]:t.join(timeout=2)
sys.exit(code)
