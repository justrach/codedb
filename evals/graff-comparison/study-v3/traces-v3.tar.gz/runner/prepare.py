import ast,hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
import run

B=Path(__file__).parent
V2=Path('/Users/blackfloofie/tmp/graff-retrieval-pr-eval-v2')
SOURCE=Path('/Users/blackfloofie/codegraff/graff-evals')
NEW=[('21-json-stream.json','json_stream.py','test_json_stream.py'),('20-map-conflict.json','doc.py','test_doc.py'),('22-validated.json','validated.py','test_validated.py'),('19-config-parse.json','config.py','test_config.py'),('17-cookie-store.json','cookie_store.py','test_cookie_store.py')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    (B/'suite-snapshot/hidden').mkdir(parents=True);(B/'runtime').mkdir();(B/'runtime/python3').symlink_to(sys.executable)
    old=json.loads((V2/'manifest.json').read_text())
    assert sha(Path(run.GRAFF))==old['graff_sha256'];assert sha(Path(run.BIN))==old['binary_sha256']
    manifest={'version':3,'model':'grok-4.6','graff_version':'0.0.296','graff_sha256':sha(Path(run.GRAFF)),'codedb_sha256':sha(Path(run.BIN)),'graphify_commit':old['graphify_commit'],'graphify_version':'0.9.58','source_commit':subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),'system_prompt':run.SYSTEM,'limits':{'model_calls':16,'tool_calls':40,'seconds':300},'arms':['baseline','codedb','graphify'],'repeats':2,'concurrency':3,'tasks':[],'setup':{},'python':sys.version,'comparison':'Matched task blocks with all three arms running concurrently; timing is secondary and subject to resource/provider contention. Baseline is the same restricted workspace harness without retrieval, not stock Graff defaults. All arms have list/search/read/write/test workspace tools. Retrieval arms are instructed to orient with retrieval. No changes after results; all prior tasks now observed.'}
    families=[]
    for t in old['tasks']:
        if t['rep']!=1:continue
        family=t['family'];template=B/'templates'/family;template.parent.mkdir(exist_ok=True);shutil.copytree(V2/'templates'/family,template)
        shutil.copy2(V2/'suite-snapshot/hidden'/f'{family}.py',B/'suite-snapshot/hidden'/f'{family}.py')
        families.append({'family':family,'prompt':t['prompt'],'editable':t['editable'],'test':t['test'],'origin':'expanded prior regression fixture','observed_before':True})
    for filename,editable,test in NEW:
        t=json.loads((SOURCE/'tasks'/filename).read_text());family=t['id'];template=B/'templates'/family
        shutil.copytree(SOURCE/t['files_dir'],template,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
        shutil.copy2(SOURCE/'hidden'/f'{family}.py',B/'suite-snapshot/hidden'/f'{family}.py')
        families.append({'family':family,'prompt':t['prompt'],'editable':[editable],'test':test,'origin':t.get('source'),'observed_before':False})
    for f in families:
        family=f['family'];template=B/'templates'/family
        for p in list(template.rglob('*.py'))+[B/'suite-snapshot/hidden'/f'{family}.py']:ast.parse(p.read_text())
        hashes={str(p.relative_to(template)):sha(p) for p in template.rglob('*') if p.is_file()}
        check=f'python3 {f["test"]} && python3 "$TASK_ROOT/hidden/{family}.py"'
        before=B/'validation-baselines'/family;before.parent.mkdir(exist_ok=True);shutil.copytree(template,before)
        assert run.checked_tests({'check':check},before,before.parent/(family+'.log'))!=0
        for rep in (1,2):
            ident=family+'-r'+str(rep)
            item={**f,'id':ident,'rep':rep,'check':check,'hashes':hashes,'hidden_sha256':sha(B/'suite-snapshot/hidden'/f'{family}.py')}
            manifest['tasks'].append(item)
            for arm in manifest['arms']:
                area=B/ident/arm;area.mkdir(parents=True);root=area/'fixture';shutil.copytree(template,root)
                subprocess.run(['git','init','-q',str(root)],check=True);subprocess.run(['git','-C',str(root),'add','.'],check=True)
                if arm=='baseline':manifest['setup'][ident+'/'+arm]={'seconds':0,'required':False};continue
                env={k:v for k,v in os.environ.items() if not k.startswith('CODEDB_')};env.update(CODEDB_NO_TELEMETRY='1',CODEDB_NO_AUTO_UPDATE='1',CODEDB_NO_CLI_DAEMON='1')
                cmd=[run.BIN,str(root),'semantic-index'] if arm=='codedb' else [run.GRAPH+'graphify','update',str(root)]
                started=time.monotonic();p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,timeout=240)
                (area/'setup.log').write_text(p.stdout+p.stderr);assert p.returncode==0,(family,arm,p.stderr[-1000:])
                manifest['setup'][ident+'/'+arm]={'seconds':time.monotonic()-started,'exit_code':p.returncode,'required':True}
            print('prepared',ident,flush=True)
    manifest['blocks']=[{'id':t['id'],'launch_order':manifest['arms'][i%3:]+manifest['arms'][:i%3]} for i,t in enumerate(manifest['tasks'])]
    (B/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
if __name__=='__main__':main()
