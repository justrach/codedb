import json,re,shutil
from pathlib import Path
import run
B=Path(__file__).parent;V2=Path('/Users/blackfloofie/tmp/graff-retrieval-pr-eval-v2')
def replace(s,old,new):
    assert old in s,old
    return s.replace(old,new)
def fixed(family,root,editable):
    if (V2/'validation'/family/'reference').exists():
        for rel in editable:shutil.copy2(V2/'validation'/family/'reference'/rel,root/rel)
        return
    path=root/editable[0];s=path.read_text()
    if family=='json-stream':
        s=replace(s,'or media.endswith("+json")','or (media.startswith("application/") and media.endswith("+json"))')
        s=replace(s,'yield json.loads(line)','if line.strip():\n                yield _decode(line)')
        s=replace(s,'yield json.loads(part)','yield _decode(part)')
        s=replace(s,'val, _end = json.JSONDecoder().raw_decode(text)','try:\n        val, _end = json.JSONDecoder().raw_decode(text)\n    except (ValueError, TypeError) as exc:\n        raise DecodingError(str(exc)) from exc\n    if text[_end:].strip():\n        raise DecodingError("trailing data")')
        s+='\n\ndef _decode(text):\n    try:\n        return json.loads(text)\n    except (ValueError, TypeError) as exc:\n        raise DecodingError(str(exc)) from exc\n'
    elif family=='map-conflict':
        s=replace(s,'self.payload = conflicts','self.conflicts = conflicts')
        start=s.index('            # BUG: applies ops before raising (not atomic)')
        end=s.index('            raise MapConflictError(conflicts)',start)
        s=s[:start]+s[end:]
        s=replace(s,'# BUG: conflicts not recorded\n            pass','self._conflicts.extend(conflicts)')
    elif family=='validated':
        s=replace(s,'return Invalid(self.value)','return Invalid((self.value,))')
        s=replace(s,'self.errors = errors\n\n    @classmethod','self.errors = (errors,)\n\n    @classmethod')
        s=replace(s,'return cls(err)','return cls((err,))')
        s=replace(s,'if isinstance(other, Invalid):\n            return self\n        return self','if isinstance(other, Invalid):\n            return Invalid(self.errors + other.errors)\n        return self')
    elif family=='config-parse':
        s=replace(s,'return key','parts = key.split("-")\n    return parts[0] + "".join(p[:1].upper() + p[1:] for p in parts[1:])')
        s=replace(s,'if not line.strip():','if not line.strip() or line.lstrip().startswith("#"):')
        s=replace(s,'for fp in found:','for fp in (list(reversed(found)) if merge_configs else found[:1]):')
        s=replace(s,'out.update(cli)\n    out.update(data)\n    out.update(env)','out.update(data)\n    out.update(env)\n    out.update(cli)')
    elif family=='cookie-store':
        s=replace(s,'cs.sort(key=lambda c: c.created)','cs.sort(key=lambda c: c.created, reverse=True)')
        s=replace(s,'self._items.sort(key=lambda c: c.created)','self._items.sort(key=lambda c: c.created, reverse=True)')
        s=replace(s,'return req_path.startswith(cookie_path)','return req_path == cookie_path or (req_path.startswith(cookie_path) and (cookie_path.endswith("/") or req_path[len(cookie_path):].startswith("/")))')
        s=replace(s,'# BUG: still stores instead of deleting\n            self.set(name, value, domain=domain, path=cpath, secure=secure)','self.delete(name, domain=domain, path=cpath)')
    else:raise AssertionError(family)
    path.write_text(s)
def main():
    m=json.loads((B/'manifest.json').read_text());records=[]
    for task in m['tasks']:
        if task['rep']!=1:continue
        family=task['family'];root=B/'validation'/family/'reference';root.parent.mkdir(parents=True);shutil.copytree(B/'templates'/family,root)
        fixed(family,root,task['editable'])
        code=run.checked_tests(task,root,root.parent/'reference.log');assert code==0,(family,(root.parent/'reference.log').read_text())
        mutant=root.parent/'mutant';shutil.copytree(root,mutant)
        for rel in task['editable']:shutil.copy2(B/'templates'/family/rel,mutant/rel)
        bad=run.checked_tests(task,mutant,root.parent/'mutant.log');assert bad!=0,family
        records.append({'family':family,'reference_exit':code,'original_bug_exit':bad})
    (B/'validation.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records))
if __name__=='__main__':main()
